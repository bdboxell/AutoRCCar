'''
    Colors
        Define all colors used in the UI here
'''
class Colors:
    grass = (33, 110, 35)
    pipe = (224, 212, 38)
    dirt = (115, 82, 53)
    car = (250, 133, 125)
    black = (0,0,0)
    red = (255,0,0)
    green = (0,255,0)
    blue = (0,0,255)
    gray = (150,150,150)
    yellow = (255,255,0)